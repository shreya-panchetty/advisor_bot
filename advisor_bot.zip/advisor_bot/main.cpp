#include "Wallet.h"
#include "MerkelMain.h"
#include <iostream>
#include <string>
#include <vector>
#include "advisorBot.h"

int main() {
	//calling the advisor bot app 
	AdvisorBot app{};
	//calling the app by the init function
	app.init();
}
