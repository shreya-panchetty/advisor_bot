//calling the advisorBot.h for function in the cpp to function
#include "advisorBot.h"
//calling command.h to get the code for comment parsing
#include "command.h"
//calling CSVReader.h to read, collect and pass the output from the csv
#include "CSVReader.h"
//calling OrderBookEntry.h
#include "OrderBookEntry.h"
//calling OrderBook.h
#include "OrderBook.h"
//initialising vector
#include <vector>
#include <iostream>
//initialising string 
#include <string>
//initialising namespace 
using namespace std;

AdvisorBot::AdvisorBot() {

}

void AdvisorBot::init() {
    //initialising input
    std::string input;

    //getting the current time from orderBook using getEarliestTime() function
    currentTime = orderBook.getEarliestTime();


    //while the condition is true then the command prompt will show print menu and 
    //will process the input made by the user
    while (true) {
        printMenu();
        input = getUserInput();
        processUserInput(input);
    }
}
//Print menu function
void AdvisorBot::printMenu() {
    //output to initiates the command input process
    std::cout << "===========================================================" << std::endl;
    std::cout << "Please enter a command, or 'help' for a list of commands." << std::endl;

}

//C2:Help command
//PrintHelp function 
void AdvisorBot::printHelp(std::vector<std::string>command_output)
{
    //C2:help
    //if the input is help
    if(command_output.size()==1)
    {
        std::cout << "The available commands are help, help <cmd>, prod, min, max, avg, predict, time,step and trend. " << std::endl;
    }

    //C2:help <command>
    //if the input is help prod
    else if (command_output[1] == "prod")
    {
        std::cout << "Purpose: list available products. " << std::endl;
        std::cout << "Command: prod " << std::endl;
        std::cout << "Command example: prod " << std::endl;
    }

    //C2:help <command>
    //if the input is help min
    else if (command_output[1] == "min")
    {
        std::cout << "Purpose: To find minimum bid or ask for product in current time step. " << std::endl;
        std::cout << "Command: min product bid/ask " << std::endl;
        std::cout << "Command example: min ETH/BTC ask " << std::endl;
    }

    //C2:help <command>
    //if the input is help max
    else if (command_output[1] == "max")
    {
        std::cout << "Purpose: To find maximum bid or ask for product in current time step. " << std::endl;
        std::cout << "Command: max product bid/ask " << std::endl;
        std::cout << "Command example: max ETH/BTC ask " << std::endl;
    }

    //C2:help <command>
    //if the input is help avg
    else if (command_output[1] == "avg")
    {
        std::cout << "Purpose: To compute average ask or bid for the sent product over the sent number. " << std::endl;
        std::cout << "Command: avg product ask/bid timesteps " << std::endl;
        std::cout << "Command example: avg ETH/BTC ask 10 " << std::endl;
    }

    //C2:help <command>
    //if the input is help predict
    else if (command_output[1] == "predict")
    {
        std::cout << "Purpose: To  predict max or min ask or bid for the sent product for the next timestep. " << std::endl;
        std::cout << "Command: min product bid/ask " << std::endl;
        std::cout << "Command example: predict max ETH/BTC bid " << std::endl;
    }

    //C2:help <command>
    //if the input is help time
    else if (command_output[1] == "time")
    {
        std::cout << "Purpose: To state current time in dataset, i.e. which timeframe are we looking at. " << std::endl;
        std::cout << "Command: time " << std::endl;
        std::cout << "Command example: time " << std::endl;
    }

    //C2:help <command>
    //if the input is help step
    else if (command_output[1] == "step")
    {
        std::cout << "Purpose: To move to the next time step. " << std::endl;
        std::cout << "Command: step" << std::endl;
        std::cout << "Command example: step " << std::endl;
    }

    //C2:help <command>
    //if the input is help trend
    else if (command_output[1] == "trend")
    {
        std::cout << "Purpose: To show the uptrend and the downtrend" << std::endl;
        std::cout << "Command: trend product ask/bid" << std::endl;
        std::cout << "Command example: trend eth/btc ask" << std::endl;
    }

    //if the input is anything else it will give an output of invalid command s
    else
    {
        std::cout << "Invalid command. Please try again. " << std::endl;
    }
}

//getUserInput function
std::string AdvisorBot::getUserInput() {
    //input string
    std::string input;
    //line string 
    std::string line;
    //output command to type 1-6
    std::cout << "Type in 1-6" << std::endl;
    std::getline(std::cin, line);
    try {
        input = line;
        //std::stoi(line);
    }
    catch (const std::exception& e)
    {
        // 
    }
    std::cout << "You chose: " << input << std::endl;
    //the function should retuen input
    return input;
}

//processUserInput function 
void AdvisorBot::processUserInput(std::string input) {
    //tokensize the input to able to accept user input 
    std::vector<std::string> command_output = CSVReader::tokenise(input, ' ');

    //string help
    std::string help = "help";
    //string prod
    std::string _prod = "prod";
    //string min
    std::string _min = "min";
    //string max
    std::string _max = "max";
    //string avg
    std::string _avg = "avg";
    //string predict
    std::string _predict = "predict";
    //string time
    std::string _time = "time";
    //string step
    std::string _step = "step";
    //string trend
    std::string _trend = "trend";
  
    //if input is help it will call printHelp function
    if (command_output[0] == help) {

        printHelp(command_output);
    }

    //if input is prod it will call view_products function
    else if (command_output[0] == _prod) {
        view_products();
    }

    //if input is min it will call minimum_ask_bid function
    else if (command_output[0] == _min) {
        //first value after spacing - product
        std::string product = command_output[1];
        // second value after spacing - type of product
        std::string type = command_output[2];
        minimum_ask_bid(product,type);
    }

    //if input is max it will call maximum_ask_bid function
    else if (command_output[0] == _max) {
        //first value after spacing - product
        std::string product = command_output[1];
        // second value after spacing - type of product
        std::string type = command_output[2];
        maximum_ask_bid(product,type);
    }

    //if input is avg it will call  average_ask_bid function
    else if (command_output[0] == _avg) {
        //first value after spacing - product
        std::string product = command_output[1];
        // second value after spacing - type of product
        std::string type = command_output[2];
        //third value after spacing - number of timesteps
        int num_timeSteps = std::stoi(command_output[3]);
        average_ask_bid(product, type,num_timeSteps);
    }

    //if input is predict it will call predict_ask_bid function
    else if (command_output[0] == _predict) {
        //first value after spacing- min or max input
        std::string predict_max_min= command_output[1];
        //second value after spacing - product
        std::string product = command_output[2];
        //third value after spacing - type of product
        std::string type = command_output[3];
        predict_ask_bid(predict_max_min, product, type);
    }

    //if input is time it will call time_step_current function
    else if (command_output[0] == _time) {
        time_step_current();
    }

    //if input is step it will call next_timeStep function
    else if (command_output[0] == _step) {
        next_timeStep();
    }

    //if input is trend it will call trend_product_type function
    else if (command_output[0] == _trend)
    {
         //first value after spacing - product
        std::string product = command_output[1];
        // second value after spacing - type of product
        std::string type = command_output[2];
        trend_product_type(product, type);
    }

    //if input is prod it will call view_products function
    else
    {
        std::cout << "Invalid input. Please enter avail input " << std::endl;
    }

};

//C3: prod
//view_products function when the input is prod
void AdvisorBot::view_products()
{
    //for loop to get the products from the csv file 
    for (std::string const& p : orderBook.getKnownProducts())
    {
        //output line to display the products
        std::cout << "Product: " << p << std::endl;
    }
}

//uppercase function
//function helps to convert the product typed in lowercase to 
//uppercse for comparsion to be faster with the csv file
std::string AdvisorBot::convertTo_upperCase(string str)
{
    //for loop to get all the alphabets and numbers
    for (int i = 0; str[i] != '\0'; i++)
    {
        //if the alphabets are in lower case
        if (str[i] >= 'a' && str[i] <= 'z') 
            //converting lowercase to upper case letters
            str[i] = str[i] - 32;        
    }
    //returning the uppercase letters as the output
    return str;
}

//C4: min function 
//minimum_ask_bid function when the input is min product type
void AdvisorBot::minimum_ask_bid(std::string product,std::string type)
{
    //getting all the entries from OrderBook entry which collects data from the csv file
    std::vector<OrderBookEntry> entries;

    //if product type= bid
    if (type == "bid")
    {
        //looping to get the products from getKnownProducts and storing its value in p 
        for (std::string const p : orderBook.getKnownProducts())
        {
            //if product input by user is same as the product stored in p by converting into uppercase
            if (convertTo_upperCase(product) == convertTo_upperCase(p)) {
                //getting enteries from orderBook where product type is bid, product and its current time
                entries = orderBook.getOrders(OrderBookType::bid,
                    p, currentTime);
            }
        }
        //if the number of entries is more than zero then it will compare over every price to get the minimum price
        if (entries.size() > 0) {
            //getting the minimum price from the orderBook function getLowPrice
            double min_price = OrderBook::getLowPrice(entries);
            //output for minimum value
            std::cout << "The minimum price for " <<product << " for " << type<< " is "<< 
             std::to_string(min_price) << std::endl;
        }
        //output if there isn't any bid/ask for a product
        else {
            std::cout << "There are currently no " << type << " for " << convertTo_upperCase(product) << std::endl;
        }
    }
    
    //if product type is ask
    if (type == "ask")
    {
        //looping to get the products from getKnownProducts and storing its value in p 
        for (std::string const p : orderBook.getKnownProducts())
        {
            //if product input by user is same as the product stored in p by converting into uppercase
            if (convertTo_upperCase(product) == convertTo_upperCase(p)) {
                //getting enteries from orderBook where product type is ask, product and its current time
                entries = orderBook.getOrders(OrderBookType::ask,
                    p, currentTime);
            }
        }
        //if the number of entries is more than zero then it will compare over every price to get the minimum price
        if (entries.size() > 0) {
            //getting the minimum price from the orderBook function getLowPrice
            double min_price = OrderBook::getLowPrice(entries);
            //output for minimum value
            std::cout << "The minimum price for " << product << " for " << type << " is " <<
                std::to_string(min_price) << std::endl;
        }
        //output if there isn't any bid/ask for a product
        else {
            std::cout << "There are currently no " << type << " for " << convertTo_upperCase(product) << std::endl;
        }
    }
}

//C5: max function 
//maximum_ask_bid function when the input is max product type    
void AdvisorBot::maximum_ask_bid(std::string product,std::string type)
{
    //getting all the entries from OrderBook entry which collects data from the csv file
    std::vector<OrderBookEntry> entries;

    //if product type= bid
    if (type == "bid")
    {
        //looping to get the products from getKnownProducts and storing its value in p 
        for (std::string const p : orderBook.getKnownProducts())
        {
            //if product input by user is same as the product stored in p by converting into uppercase
            if (convertTo_upperCase(product) == convertTo_upperCase(p)) {
                //getting enteries from orderBook where product type is bid, product and its current time
                entries = orderBook.getOrders(OrderBookType::bid,
                    p, currentTime);
            }
        }
        //if the number of entries is more than zero then it will compare over every price to get the maximum price
        if (entries.size() > 0) {
            //getting the maximum price from the orderBook function getHighPrice
            double max_price = OrderBook::getHighPrice(entries);
            //output for maximum price
            std::cout << "The maximum price for " <<
                convertTo_upperCase(product) << " for " << type << " is " << std::to_string(max_price) << std::endl;
        }
        //output if there isn't any bid/ask for a product
        else {
            std::cout << "There are currently no " << type << " for " << convertTo_upperCase(product) << std::endl;
        }
    }
    //if product type= ask
    if (type == "ask")
    {
        //looping to get the products from getKnownProducts and storing its value in p 
        for (std::string const p : orderBook.getKnownProducts())
        {
            //if product input by user is same as the product stored in p by converting into uppercase
            if (convertTo_upperCase(product) == convertTo_upperCase(p)) {
                //getting enteries from orderBook where product type is ask, product and its current time
                entries = orderBook.getOrders(OrderBookType::bid,
                    p, currentTime);
            }
        }
        //if the number of entries is more than zero then it will compare over every price to get the maximum price
        if (entries.size() > 0) {
            //getting the maximum price from the orderBook function getHighPrice
            double max_price = OrderBook::getHighPrice(entries);
            //output for maximum price
            std::cout << "The maximum price for " <<
                convertTo_upperCase(product) << " for " << type << " is " << std::to_string(max_price) << std::endl;
        }
        //output if there isn't any bid/ask for a product
        else {
            std::cout << "There are currently no " << type << " for " << convertTo_upperCase(product) << std::endl;
        }
    }
}

//C6: avg function 
//average_ask_bid function when the input is avg product type num_timeSteps
void AdvisorBot::average_ask_bid(std::string product, std::string type, int num_timeSteps)
{
    //initialising variable i
    int i;
    //initialising sum to be zero to accept values when added
    double sum_of_entries = 0;
    //initialising average to be zero to accept values when added
    double average_of_entries = 0;
    //getting all the entries from OrderBook entry which collects data from the csv file
    std::vector<OrderBookEntry> entries;

    //if product type= bid
    if (type == "bid")
    {
        //looping to get the products from getKnownProducts and storing its value in p 
        for (std::string const p : orderBook.getKnownProducts())
        {
            //if product input by user is same as the product stored in p by converting into uppercase
            if (convertTo_upperCase(product) == convertTo_upperCase(p)) {
                //getting enteries from orderBook where product type is bid, product and its current time
                entries = orderBook.getOrders(OrderBookType::bid,
                    p, currentTime);
            }
        }
        //if the number of entries is more than zero then depending on the number of timesteps input 
        //the prices will added and then divided to get the average
        if (entries.size() > 0)
        {
            //looping the number of entries based on the num_timSteps
            for (i = 0; i < num_timeSteps; i++)
            {
                //sum of entries
                sum_of_entries = entries[i].price + sum_of_entries;
            }
            //average of entries
            average_of_entries = sum_of_entries / num_timeSteps;
            //output for average price
            std::cout << "The average " << convertTo_upperCase(product) << 
                " for "<< type<< " is "  << average_of_entries << std::endl;
        }
        //output if there isn't any average for a product 
        else {
            std::cout << "There are currently no average for " << convertTo_upperCase(product)
                <<" for " << type  << std::endl;
        }
    }

    //if product type= ask
    if (type == "ask")
    {
        //looping to get the products from getKnownProducts and storing its value in p 
        for (std::string const p : orderBook.getKnownProducts())
        {
            //if product input by user is same as the product stored in p by converting into uppercase
            if (convertTo_upperCase(product) == convertTo_upperCase(p)) {
                //getting enteries from orderBook where product type is ask, product and its current time
                entries = orderBook.getOrders(OrderBookType::bid,
                    p, currentTime);
            }
        }
        // if the number of entries is more than zero then depending on the number of timesteps input
        //the prices will added and then divided to get the average
        if (entries.size() > 0)
        {
            //looping the number of entries based on the num_timSteps
            for (i = 0; i < num_timeSteps; i++)
            {
                //sum of entries
                sum_of_entries = entries[i].price + sum_of_entries;
            }
            //average of entries
            average_of_entries = sum_of_entries / num_timeSteps;
            //output for average price
             std::cout << "The average " << convertTo_upperCase(product) <<
                 " for " << type << " is " << average_of_entries << std::endl;
        }
        //output if there isn't any average for a product 
        else {
                std::cout << "There are currently no average for " << convertTo_upperCase(product)
                    << " for " << type << std::endl;
        }

    }
}

//C7: predict function 
//predict_ask_bid function when the input is predict max/min product type
void AdvisorBot::predict_ask_bid(std::string predict_max_min, std::string product, std::string type)
{
    //initialising variable i
    int i;
    //initialising sum to be zero to accept values when added
    double sum_of_entries = 0;
    //initialising average to be zero to accept values when added
    double average_of_entries = 0;
    //getting all the entries from OrderBook entry which collects data from the csv file
    std::vector<OrderBookEntry> entries;
    std::string currentTime_frame;

    //input is max
    if (predict_max_min == "max")
    {
        //if product type= bid
        if (type == "bid")
        {
            //looping to get the products from getKnownProducts and storing its value in p 
            for (std::string const p : orderBook.getKnownProducts())
            {
                //if product input by user is same as the product stored in p by converting into uppercase
                if (convertTo_upperCase(product) == convertTo_upperCase(p)) {
                    //getting the next time step using goNextTime function from orderbook
                    currentTime_frame = orderBook.getNextTime(currentTime);
                    //getting enteries from orderBook where product type is bid, product and its current time
                    entries = orderBook.getOrders(OrderBookType::bid, p, currentTime_frame);
                }
            }
            // if the number of entries is more than zero then depending on the next 10 timesteps
            //the prices will added and then divided to get the average
            if (entries.size() > 0) {
                //get the maximum price from the next timeStep
                double max_price = OrderBook::getHighPrice(entries);
                //looping the number of entries for 10 timeSteps
                    for (i = 0; i < 10; i++)
                    {
                        //sum of entries
                        sum_of_entries = entries[i].price + sum_of_entries;
                    }
                    //average of entries
                    average_of_entries = sum_of_entries / 10;
                    //output for predicted maximum price in the nextTimeStep
                std::cout << "The predicted maximum price for " << convertTo_upperCase(product) << " for " 
                    << type << " over the next time step is " << max_price << std::endl;
                //output for the average price over the next 10 time steps
                std::cout << "The predicted average price for " << convertTo_upperCase(product) << " for "
                    << type << " over the next 10 time steps is " << average_of_entries << std::endl;
            }
        }

        //if product type= ask
        if (type == "ask")
        {
            //looping to get the products from getKnownProducts and storing its value in p 
            for (std::string const p : orderBook.getKnownProducts())
            {
                //if product input by user is same as the product stored in p by converting into uppercase
                if (convertTo_upperCase(product) == convertTo_upperCase(p))
                {
                    //getting the next time step using goNextTime function from orderbook
                    currentTime_frame = orderBook.getNextTime(currentTime);
                    //getting enteries from orderBook where product type is ask, product and its current time
                    entries = orderBook.getOrders(OrderBookType::ask, p, currentTime_frame);
                }
            }
            // if the number of entries is more than zero then depending on the next 10 timesteps
            //the prices will added and then divided to get the average
            if (entries.size() > 0) {
                //get the maximum price from the next timeStep
                double max_price = OrderBook::getHighPrice(entries);
                //looping the number of entries for 10 timeSteps
                for (i = 0; i < 10; i++)
                {
                    //sum of entries
                    sum_of_entries = entries[i].price + sum_of_entries;
                }
                //average of entries
                average_of_entries = sum_of_entries / 10;
                //output for predicted maximum price in the nextTimeStep
                std::cout << "The predicted maximum price for " << convertTo_upperCase(product) << " for "
                    << type << " over the next time step is " << max_price << std::endl;
                //output for the average price over the next 10 time steps
                std::cout << "The predicted average price for " << convertTo_upperCase(product) << " for "
                    << type << " over the next 10 time steps is " << average_of_entries << std::endl;
            }
        }
    }
    //input is min
    if (predict_max_min == "min")
    {
        //if product type= bid
        if (type == "bid")
        {
            //looping to get the products from getKnownProducts and storing its value in p 
            for (std::string const p : orderBook.getKnownProducts())
            {
                //if product input by user is same as the product stored in p by converting into uppercase
                if (convertTo_upperCase(product) == convertTo_upperCase(p)) {
                    //getting the next time step using goNextTime function from orderbook
                    currentTime_frame = orderBook.getNextTime(currentTime);
                    //getting enteries from orderBook where product type is bid, product and its current time
                    entries = orderBook.getOrders(OrderBookType::bid, p, currentTime_frame);
                }
            }
            // if the number of entries is more than zero then depending on the next 10 timesteps
           //the prices will added and then divided to get the average
            if (entries.size() > 0) {
                //get the minimum price from the next timeStep
                double min_price = OrderBook::getLowPrice(entries);
                //looping the number of entries for 10 timeSteps
                for (i = 0; i < 10; i++)
                {
                    //sum of entries
                    sum_of_entries = entries[i].price + sum_of_entries;
                }
                //average of entries
                average_of_entries = sum_of_entries / 10;
                //output for predicted minimum price in the nextTimeStep
                std::cout << "The predicted minimum price for " <<convertTo_upperCase(product) << " for " 
                    << type << " over the next time step is " << min_price << std::endl;
                //output for the average price over the next 10 time steps
                std::cout << "The predicted average price for " << convertTo_upperCase(product) << " for "
                    << type << " over the next 10 time steps is " << average_of_entries << std::endl;
            }
        }
        //if product type= ask
        if (type == "ask")
        {
            //looping to get the products from getKnownProducts and storing its value in p 
            for (std::string const p : orderBook.getKnownProducts())
            {
                //if product input by user is same as the product stored in p by converting into uppercase
                if (convertTo_upperCase(product) == convertTo_upperCase(p))
                {
                    //getting the next time step using goNextTime function from orderbook
                    currentTime_frame = orderBook.getNextTime(currentTime);
                    //getting enteries from orderBook where product type is ask, product and its current time
                    entries = orderBook.getOrders(OrderBookType::ask, p, currentTime_frame);
                }
            }
            // if the number of entries is more than zero then depending on the next 10 timesteps
            //the prices will added and then divided to get the average
            if (entries.size() > 0) {
                //get the minimum price from the next timeStep
                double min_price = OrderBook::getLowPrice(entries);
                //looping the number of entries for 10 timeSteps
                for (i = 0; i < 10; i++)
                {
                    //sum of entries
                    sum_of_entries = entries[i].price + sum_of_entries;
                }
                //average of entries
                average_of_entries = sum_of_entries / 10;
                //output for predicted minimum price in the nextTimeStep
                std::cout << "The predicted minimum price for " << convertTo_upperCase(product) << " for "
                    << type << " over the next time step is " << min_price << std::endl;
                //output for the average price over the next 10 time steps
                std::cout << "The predicted average price for " << convertTo_upperCase(product) << " for "
                    << type << " over the next 10 time steps is " << average_of_entries << std::endl;
            }
        }
    }
    //output if there isn't any predict for a product 
    else {
        std::cout << "There are currently no predict for " << convertTo_upperCase(product)
            << " for " << type << std::endl;
    }
}

//C8:time function
//time_step_current function when the input is time
void AdvisorBot::time_step_current()
{
    //output to get the current time 
    std::cout << "Current time is " << currentTime << std::endl;
}

//C9:step function
//next_timeStep() function when the input is step
void AdvisorBot::next_timeStep()
{
    //getting the current time of the next time step from the getNextTime function from orderbook
    currentTime = orderBook.getNextTime(currentTime);
    //output for the next step
    std::cout << "The next time step is " << currentTime << std::endl;

}

//Task 2-implementing own function
//trend function
//trend_product_type fumction when the input is trend product type
void AdvisorBot::trend_product_type(std::string product, std::string type)
{
    //initialising variable i
    int i;
    //initialising sum to be zero to accept values when added
    double sum_of_entries = 0;
    //initialising average to be zero to accept values when added
    double average_of_entries = 0;
    //initialising uptrend
    double uptrend_of_entries = 0;
    //initialising downtrend 
    double downtrend_of_entries = 0;
    currentTime = orderBook.getEarliestTime();
    //getting all the entries from OrderBook entry which collects data from the csv file
    std::vector<OrderBookEntry> entries;
    
    //if product type= bid
    if (type == "bid")
    {
        //looping to get the products from getKnownProducts and storing its value in p 
        for (std::string const p : orderBook.getKnownProducts())
        {
            //if product input by user is same as the product stored in p by converting into uppercase
            if (convertTo_upperCase(product) == convertTo_upperCase(p)) {
                //getting the next time step using goNextTime function from orderbook
                currentTime = orderBook.getNextTime(currentTime);
                //getting enteries from orderBook where product type is bid, product and its current time
                entries = orderBook.getOrders(OrderBookType::bid, p, currentTime);
            }
        }
        // if the number of entries is more than zero then depending on the next 10 timesteps
        //the prices will added and then divided to get the average
        if (entries.size() > 0) {
            //looping the number of entries for 10 timeSteps
            for (i = 0; i < 10; i++)
            {
                //sum of entries
                sum_of_entries = entries[i].price + sum_of_entries;
            }
            //average of entries
            average_of_entries = sum_of_entries / 10;
            //looping for 10 time steps
            for (i = 0; i < 10; i++)
            {
                //if the price is less the average price then downtrend value will increase
                if (average_of_entries > entries[i].price)
                {
                    //downtrend of entries 
                    downtrend_of_entries = downtrend_of_entries++;
                }
                //if the price is more the average price then uptrend value will increase
                if(average_of_entries < entries[i].price)
                {
                    //uptrend of entries
                    uptrend_of_entries = uptrend_of_entries++;
                }
            }
            //output for uptrend and downtrend 
            std::cout << "The number of Uptrends: " << uptrend_of_entries
                << " The number of Downtrends: " << downtrend_of_entries
                << " are the " << type << " prices over next 10 timeSteps" << std::endl;

        }
    }

    //if product type= ask
    if (type == "ask")
    {
        //looping to get the products from getKnownProducts and storing its value in p 
        for (std::string const p : orderBook.getKnownProducts())
        {
            //if product input by user is same as the product stored in p by converting into uppercase
            if (convertTo_upperCase(product) == convertTo_upperCase(p)) {
                //getting the next time step using goNextTime function from orderbook
                currentTime = orderBook.getNextTime(currentTime);
                //getting enteries from orderBook where product type is ask, product and its current time
                entries = orderBook.getOrders(OrderBookType::ask, p, currentTime);
            }
        }
        // if the number of entries is more than zero then depending on the next 10 timesteps
        //the prices will added and then divided to get the average
        if (entries.size() > 0) {
            //looping the number of entries for 10 timeSteps
            for (i = 0; i < 10; i++)
            {
                //sum of entries
                sum_of_entries = entries[i].price + sum_of_entries;
            }
            //average of entries
            average_of_entries = sum_of_entries / 10;
            //looping for 10 time steps
            for (i = 0; i < 10; i++)
            {
                //if the price is less the average price then downtrend value will increase
                if (average_of_entries > entries[i].price)
                {
                    //downtrend of entries 
                    downtrend_of_entries = downtrend_of_entries++;
                }
                //if the price is more the average price then uptrend value will increase
                if (average_of_entries < entries[i].price)
                {
                    //uptrend of entries
                    uptrend_of_entries = uptrend_of_entries++;
                }
            }
            //output for uptrend and downtrend 
            std::cout << "The number of Uptrends: " << uptrend_of_entries
                << " The number of Downtrends: " << downtrend_of_entries
                << " are the " << type << " prices over next 10 timeSteps" << std::endl;

        }
    }
    //output if there isn't any trend for a product 
    else {
        std::cout << "There are currently no trend for " << convertTo_upperCase(product)
            << " for " << type << std::endl;
    }
}