#pragma once
#include <string>
#include <vector>
#include <fstream>
class command
{
public:
	static std::vector<std::string> parse(std::string input, char separator);

private:

};
