#pragma once
//initialising the string 
#include <string>
//initialising vector
#include <vector>
//initialising map
#include <map>
//calling orderbookentry.h 
#include "OrderBookEntry.h";
//calling orderBook
#include "OrderBook.h"


class AdvisorBot
{
public:
    // advior bot app
    AdvisorBot();
    void init();

private:
    //initialising the functions to be called inthe advisorBot.cpp

    //initialising print menu function which prints the text for the user to enter a command
    void printMenu();

    //initialising getUserInput() string for input to be processed
    std::string getUserInput();

    //initilaising processUserInput() function for input to be processed
    void processUserInput(std::string input);

    //initilaising printHelp() function for output for the help command
    void printHelp(std::vector<std::string> command_output);

    //initilaising view_product() function
    void view_products();

    //Calling the csv file 
    OrderBook orderBook{ "20200601.csv" };

    //initialising the currentTime string to get the current time
    std::string currentTime;

    //initialising convertTo_upperCase function to convert
    //input by the user into uppercase for the comparison
    std::string convertTo_upperCase(std::string str);

    //initialising minimum_ask_bid() to get the minimum price
    void minimum_ask_bid(std::string product, std::string type);

    //initialising maximum_ask_bid() to get the maximum price
    void maximum_ask_bid(std::string product, std::string type);

    //initialising average_ask_bid() to get the average price over a number of timesteps 
    void average_ask_bid(std::string product, std::string type, int num_timeSteps);

    //initialising predict() to get the prdict the price for the next timestep
    void predict_ask_bid(std::string predict_max_min, std::string product, std::string type);

    //initialising time_current() to get the time at the current moment from the csv file
    void time_step_current();

    //initialising next_timeStep() to get the nect timestep from the csv file
    void next_timeStep();

    //initialising trend() to get the uptrend and downtrend over a number of timesteps
    void trend_product_type(std::string product, std::string type);
};
